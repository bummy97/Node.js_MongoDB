const express = require('express');
const app = express();
const bodyParser = require('body-parser');
app.use(bodyParser.urlencoded({
    extended: true
}));
app.use('/public', express.static('public'));
const MongoClient = require('mongodb').MongoClient;
const methodOverride = require('method-override');
const {
    ObjectId
} = require('mongodb');
app.use(methodOverride('_method'));
app.set('view engine', 'ejs');

require('dotenv').config();





var db;
MongoClient.connect(process.env.DB_URL, function (에러, client) {
    if (에러) {
        return console.log(에러);
    }

    db = client.db('todoapp');
    // db.collection('post').insertOne({
    //     이름: 'John',
    //     나이: 20
    // }, function (에러, 결과) {
    //     console.log('저장완료');
    // });

    app.listen(8080, function () {
        console.log('listening on 8080');
    });
});

app.get('/pet', function (요청, 응답) {
    응답.send('펫용품 쇼핑할 수 있는 페이지입니다.');
});
//누군가가 /pet으로 방문을 하면 pet과련된 안내문 띄우기

///beauty로 들어오면 beauty와 관련된 안애문 띄워주기: 숙제

app.get('/beauty', function (요청, 응답) {
    응답.send('뷰티용품 쇼핑 페이지입니다.');
})

//서버를 띄우기 위한 기본 셋팅 (express 라이브러리)
//서버에 get요청을 하면 해당 url로 변경됨 

//이제 html로 보내기위해서 작성하는 코드 
// '/' 하나만 쓰면 홈이라는 뜻
app.get('/', function (요청, 응답) {
    응답.render('index.ejs');
})

app.get('/write', function (요청, 응답) {
    응답.render('write.ejs');
})

app.get('/list', function (요청, 응답) {
    //디비에 저장된 POST라는 collection안의 모든 데이터를 꺼내보자
    db.collection('post').find().toArray(function (에러, 결과) {
        응답.render('list.ejs', {
            posts: 결과
        });
    });
});


app.get('/detail/:id', function (요청, 응답) {
    db.collection('post').findOne({
        _id: parseInt(요청.params.id)
    }, function (에러, 결과) {
        console.log(결과);
        응답.render('detail.ejs', {
            data: 결과
        });
    });

});

app.get('/edit/:id', function (요청, 응답) {
    db.collection('post').findOne({
        _id: parseInt(요청.params.id)
    }, function (에러, 결과) {
        console.log(결과);
        응답.render('edit.ejs', {
            post: 결과
        });
    });
});

app.put('/edit', function (요청, 응답) {
    db.collection('post').updateOne({
            _id: parseInt(요청.body.id)
        }, {
            $set: {
                할일: 요청.body.title,
                날짜: 요청.body.date
            }
        },
        function (에러, 결과) {
            console.log('수정완료');
            응답.redirect('/list');
        })
});

const passport = require('passport');
const LocalStrategy = require('passport-local').Strategy;
const session = require('express-session');

app.use(session({
    secret: '비밀코드',
    resave: true,
    saveUninitialized: false
}));
app.use(passport.initialize());
app.use(passport.session());



app.get('/login', function (에러, 응답) {
    응답.render('login.ejs');
});

app.post('/login', passport.authenticate('local', {
    failureRedirect: '/fail' //사용자가 로그인을 실패하면 이경로로('/fail') 이동시켜주세요 
}), function (요청, 응답) {
    응답.redirect('/');
});

passport.use(new LocalStrategy({
    usernameField: 'id',
    passwordField: 'pw', //유저가 입력한 아이디/비번 항복이 뭔지 정의 (name 속성)
    session: true, //로그인 후 세션을 저장할 것인지
    passReqToCallback: false, //이름이나 다른 것들 검증해보고 싶다고 할때 사용하는 것 뒤 function에 req 인자 하나 더 받아야함-
}, function (입력한아이디, 입력한비번, done) {
    //console.log(입력한아이디, 입력한비번);
    db.collection('login').findOne({
        id: 입력한아이디
    }, function (에러, 결과) {
        if (에러) return done(에러)

        if (!결과) return done(null, false, {
            message: '존재하지않는 아이디요'
        })
        if (입력한비번 == 결과.pw) {
            return done(null, 결과)
        } else {
            return done(null, false, {
                message: '비번틀렸어요'
            })
        }
    })
}));

app.get('/mypage', 로그인했니, function (요청, 응답) {
    console.log(요청.user);
    응답.render('mypage.ejs', {
        사용자: 요청.user
    });
});

function 로그인했니(요청, 응답, next) {
    if (요청.user) {
        next()
    } else {
        응답.send('로그인안하셨는데요?');
    }
};

passport.serializeUser(function (user, done) { //id를 이용해서 세션을 저장시키는 코드 
    done(null, user.id)
});
passport.deserializeUser(function (아이디, done) { //이 세션을 가진 데이터를 가진 사람을 DB에서 찾아주세요
    db.collection('login').findOne({
        id: 아이디
    }, function (에러, 결과) {
        done(null, 결과)
    })
});

app.post('/register', function (요청, 응답) {
    db.collection('login').insertOne({
        id: 요청.body.id,
        pw: 요청.body.pw
    }, function (에러, 결과) {
        응답.redirect('/')
    })
});

app.get('/signup', function (에러, 응답) {
    응답.render('signup.ejs');
});

app.post('/add', function (요청, 응답) {
    응답.send('전송완료');
    db.collection('counter').findOne({
        name: '게시물갯수'
    }, function (에러, 결과) {
        console.log(결과.totalPost);
        var 총게시물갯수 = 결과.totalPost;

        var 저장할거 = {
            _id: 총게시물갯수 + 1,
            할일: 요청.body.title,
            날짜: 요청.body.date,
            작성자: 요청.user._id
        }

        db.collection('post').insertOne(저장할거, function (에러, 결과) {
            console.log('저장완료');
            //counter라는 콜렉션에 있는 totalPost라는 항목도 1 증가시켜야함
            db.collection('counter').updateOne({
                name: '게시물갯수'
            }, {
                $inc: {
                    totalPost: 1
                }
            }, function (에러, 결과) {
                if (에러) {
                    return console.log(에러);
                }
            }); //DB 데이터를 수정해주세요

        });


    });

});

app.delete('/delete', function (요청, 응답) {
    //DB에서 글 삭제해주세요
    console.log('삭제요청이 들어왔습니다.');
    console.log(요청.body);
    요청.body._id = parseInt(요청.body._id);

    var 삭제할데이터 = {
        _id: 요청.body._id,
        작성자: 요청.user._id
    };

    db.collection('post').deleteOne(삭제할데이터, function (에러, 결과) {
        console.log('삭제완료');
        if (결과) {
            console.log(결과);
        }
        응답.status(200).send({
            message: '성공했습니다.'
        }); //성공하면 응답코드 200을 보내주세요 200은 성공했다는 뜻
    });
});

app.post('/signup', forsignup, function (요청, 응답) {
    //db에 입력한 아이디가 없어야 실행시킬수 있음 
    db.collection('login').insertOne({
            id: 요청.body.id,
            pw: 요청.body.pw
        },
        function (요청, 응답) {
            console.log('회원가입 완료');
        })
    응답.redirect('/');
});

function forsignup(요청, 응답, next) {
    db.collection('login').findOne({
        id: 요청.body.id
    }, function (에러, 결과) {
        if (!결과) {
            next()
        } else {
            응답.send('중복된 아이디입니다');
        }
    })
};

app.get('/search', (요청, 응답) => {
    var 검색조건 = [{
            $search: {
                index: 'titleSearch',
                text: {
                    query: 요청.query.value,
                    path: '할일' // 제목날짜 둘다 찾고 싶으면 ['제목', '날짜']
                }
            }
        },
        {
            $sort: {
                _id: 1
            }
        }
    ]
    db.collection('post').aggregate(검색조건).toArray((에러, 결과) => {
        console.log(결과);
        응답.render('search.ejs', {
            posts: 결과
        });
    })
});


app.use('/shop', require('./routes/shop.js'));
app.use('/board/sub', require('./routes/board.js'));




let multer = require('multer');
var storage = multer.diskStorage({
    destination: function (req, file, cb) {
        cb(null, './public/image')
    },
    filename: function (req, file, cb) {
        cb(null, file.originalname)
    }
});

var upload = multer({
    storage: storage
});

app.get('/upload', function (요청, 응답) {
    응답.render('upload.ejs');
});

app.post('/upload', upload.single('profile'), function (요청, 응답) {
    응답.send('완료');
});

app.get('/image/:imagename', function (요청, 응답) {
    응답.sendFile(__dirname + '/public/image/' + 요청.params.imagename);
});

app.post('/chatroom', 로그인했니, function (요청, 응답) {
    var 저장할거 = {
        title: 요청.body.title,
        member: [ObjectId(요청.body.받은사람id), 요청.user._id],
        date: new Date()
    }
    db.collection('chatroom').insertOne(저장할거).then((결과) => {
        응답.send('성공')
    });
});

app.get('/chat', 로그인했니, function (요청, 응답) {
    db.collection('chatroom').find({
        member: 요청.user._id
    }).toArray().then((결과) => {
        응답.render('chat.ejs', {
            data: 결과
        });
    })
});


app.post('/message', 로그인했니, function (요청, 응답) {

    var 저장할거 = {
        parent: 요청.body.parent,
        content: 요청.body.content,
        userid: 요청.user._id,
        date: new Date()
    }
    db.collection('message').insertOne(저장할거).then(() => {
        console.log('성공');
        응답.send('DB저장성공');
    })
});


app.get('/message/:id', 로그인했니, function (요청, 응답) {

    응답.writeHead(200, {
        "Connection": "keep-alive",
        "Content-Type": "text/event-stream",
        "Cache-Control": "no-cache",
    })

    db.collection('message').find({
        parent: 요청.params.id
    }).toArray().then((결과) => {
        응답.write('event: test\n');
        응답.write('data:' + JSON.stringify(결과) + '\n\n');
    })

    const pipeline = [{
        $match: {
            'fullDocument.parent': 요청.params.id
        }
    }];
    const collection = db.collection('message');
    const changeStream = collection.watch(pipeline);
    changeStream.on('change', (result) => {
        응답.write('event: test\n');
        응답.write('data:' + JSON.stringify([result.fullDocument]) + '\n\n');
    });

})